require( "mod-gui" )
require( "util/gui")
require( "util/productionCalculations")
require( "util/logisticCalculations")

-- Functions
local function PSC_onRemove(entity)
	-- Search through and remove entity
	-- Production
	for i, e in ipairs(global.PSCEntitiesInput) do
		if e == entity then
			table.remove(global.PSCEntitiesInput, i)
			return
		end
	end
	
	for i, e in ipairs(global.PSCEntitiesOutput) do
		if e == entity then
			table.remove(global.PSCEntitiesOutput, i)
			return
		end
	end
	
	for i, e in ipairs(global.PSCEntitiesTotal) do
		if e == entity then
			table.remove(global.PSCEntitiesTotal, i)
			return
		end
	end
	
	for i, e in ipairs(global.PSCEntitiesPercentage) do
		if e == entity then
			table.remove(global.PSCEntitiesPercentage, i)
			return
		end
	end
	
	-- Logistic
	for i, e in ipairs(global.LSCEntitiesAvailableItems) do
		if e == entity then
			table.remove(global.LSCEntitiesAvailableItems, i)
			return
		end
	end
	
	for i, e in ipairs(global.LSCEntitiesRequests) do
		if e == entity then
			table.remove(global.LSCEntitiesRequests, i)
			return
		end
	end
	
	for i, e in ipairs(global.LSCEntitiesRequestsRemaining) do
		if e == entity then
			table.remove(global.LSCEntitiesRequestsRemaining, i)
			return
		end
	end
	
	for i, e in ipairs(global.LSCEntitiesStatus) do
		if e == entity then
			table.remove(global.LSCEntitiesStatus, i)
			return
		end
	end
end

script.on_event (defines.events.on_entity_died, function (event)
	if event then
		if event.entity.name == "production-statistics-combinator" or event.entity.name == "logistic-statistics-combinator" then
			PSC_onRemove(event.entity)
		end
	end
end )

script.on_event (defines.events.on_pre_player_mined_item, function (event)
	if event then
		if event.entity.name == "production-statistics-combinator" or event.entity.name == "logistic-statistics-combinator" then
			PSC_onRemove(event.entity)
		end
	end
end )

script.on_event (defines.events.on_robot_pre_mined, function (event)
	if event then
		if event.entity.name == "production-statistics-combinator" or event.entity.name == "logistic-statistics-combinator" then
			PSC_onRemove(event.entity)
		end
	end
end )

script.on_init( function()
	global.PSCEntitiesInput = global.PSCEntitiesInput or {}
	global.PSCEntitiesOutput = global.PSCEntitiesOutput or {}
	global.PSCEntitiesTotal = global.PSCEntitiesTotal or {}
	global.PSCEntitiesPercentage = global.PSCEntitiesPercentage or {}
	global.PSCStatistics = {}
	global.PSCSignals = {}
	
	global.PSC_PlayerData = global.PSC_PlayerData or {}
	global.PSC_StatMultiplier = game.speed * 300 / settings.global["Production-Statistics-Updates"].value
	
	global.LSCEntitiesRequests = global.LSCEntitiesRequests or {}
	global.LSCEntitiesRequestsRemaining = global.LSCEntitiesRequestsRemaining or {}
	global.LSCEntitiesStorage = global.LSCEntitiesStorage or {}
	global.LSCEntitiesAvailableItems = LSCEntitiesAvailableItems or {}
	global.LSCEntitiesStatus = global.LSCEntitiesStatus or {}
end )

script.on_configuration_changed( function()
	global.PSCEntitiesInput = global.PSCEntitiesInput or {}
	global.PSCEntitiesOutput = global.PSCEntitiesOutput or {}
	global.PSCEntitiesTotal = global.PSCEntitiesTotal or {}
	global.PSCEntitiesPercentage = global.PSCEntitiesPercentage or {}
	global.PSCStatistics = {}
	global.PSCSignals = {}
	
	global.PSC_PlayerData = global.PSC_PlayerData or {}
	global.PSC_StatMultiplier = game.speed * 300 / settings.global["Production-Statistics-Updates"].value
	
	global.LSCEntitiesRequests = global.LSCEntitiesRequests or {}
	global.LSCEntitiesRequestsRemaining = global.LSCEntitiesRequestsRemaining or {}
	global.LSCEntitiesAvailableItems = LSCEntitiesAvailableItems or {}
	global.LSCEntitiesStatus = global.LSCEntitiesStatus or {}
end )

script.on_event (defines.events.on_tick, function (event)
	if event.tick % ( game.speed * settings.global["Production-Statistics-Updates"].value ) == 0 then
			
		-- PSC Stats
		if #global.PSCEntitiesInput > 0 or #global.PSCEntitiesOutput > 0 or #global.PSCEntitiesTotal > 0 or #global.PSCEntitiesPercentage > 0 then
			-- Update previous Stats
			PSC_updatePreviousStats()
			
			-- Apply Signals
			-- Input
			local stats = {}
			for i, c in pairs (global.PSCEntitiesInput) do
				local force = c.force
			
				if not stats[force.name] then
					PSC_getStatsForForce(force)
					stats[force.name] = true
				end
			
				local signals = PSC_getInputSignals(force)
				
				if c then
					local behavior = c.get_or_create_control_behavior()
					
					if #signals > 0 then
						behavior.parameters = { parameters = signals }
					end
				end
			end
			
			-- Output
			for i, c in pairs (global.PSCEntitiesOutput) do
				local force = c.force
			
				if not stats[force.name] then
					PSC_getStatsForForce(force)
					stats[force.name] = true
				end

				local signals = PSC_getOutputSignals(force)
				
				if c then
					local behavior = c.get_or_create_control_behavior()
					if #signals > 0 then
						behavior.parameters = { parameters = signals }
					end
				end
			end
			
			-- Total
			for i, c in pairs (global.PSCEntitiesTotal) do
				local force = c.force
			
				if not stats[force.name] then
					PSC_getStatsForForce(force)
					stats[force.name] = true
				end
				
				local signals = PSC_getTotalSignals(force)
			
				if c then
					local behavior = c.get_or_create_control_behavior()
					if #signals > 0 then
						behavior.parameters = { parameters = signals }
					end
				end
			end
			
			-- Percentage
			for i, c in pairs (global.PSCEntitiesPercentage) do
				local force = c.force
			
				if not stats[force.name] then
					PSC_getStatsForForce(force)
					stats[force.name] = true
				end
				
				local signals = PSC_getPercentageSignals(force)
			
				if c then
					local behavior = c.get_or_create_control_behavior()
					if #signals > 0 then
						behavior.parameters = { parameters = signals }
					end
				end
			end
		end
		
		-- LSC Stats
		if #global.LSCEntitiesRequests > 0 or #global.LSCEntitiesRequestsRemaining > 0 or #global.LSCEntitiesAvailableItems > 0 or #global.LSCEntitiesStatus > 0 then
			-- Apply Signals
			-- Requests
			if #global.LSCEntitiesRequests > 0 then
				
				for i, c in pairs(global.LSCEntitiesRequests) do
					if c then
						-- Get Signals
						local signals = PSC_getRequestSignals(c)
					
						local behavior = c.get_or_create_control_behavior()
						if #signals > 0 then
							behavior.parameters = { parameters = signals }
						end
					end
				end
			end
			
			-- Requests Remaining
			if #global.LSCEntitiesRequestsRemaining > 0 then
				for i, c in pairs(global.LSCEntitiesRequestsRemaining) do
					if c then
						-- Get Signals
						local signals = PSC_getRequestsRemainingSignals(c)
						
						local behavior = c.get_or_create_control_behavior()
						if #signals > 0 then
							behavior.parameters = { parameters = signals }
						end
					end
				end
			end
			
			-- Available Items
			if #global.LSCEntitiesAvailableItems > 0 then
				for i, c in pairs(global.LSCEntitiesAvailableItems) do
					if c then
						-- Get Signals
						local signals = PSC_getAvailableItemsSignals(c)
						
						local behavior = c.get_or_create_control_behavior()
						if #signals > 0 then
							behavior.parameters = { parameters = signals }
						end
					end
				end
			end
			
			-- Status
			if #global.LSCEntitiesStatus > 0 then
				for i, c in pairs(global.LSCEntitiesStatus) do
					if c then
						-- Get Signals
						local signals = PSC_getStatusSignals(c)
						
						local behavior = c.get_or_create_control_behavior()
						if #signals > 0 then
							behavior.parameters = { parameters = signals }
						end
					end
				end
			end
		end
	end
end )