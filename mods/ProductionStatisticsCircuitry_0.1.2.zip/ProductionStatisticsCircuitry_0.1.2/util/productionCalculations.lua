function PSC_getStatsForForce(force)
	-- Check array
	if global.PSCStatistics == nil then
		global.PSCStatistics = {}
	end
	if global.PSCStatistics[force.name] == nil then
		global.PSCStatistics[force.name] = {}
	end

	if force then	
		-- Item Production Input
		for itemName, itemCount in pairs (force.item_production_statistics.input_counts) do
			if itemName ~= nil and itemCount ~= 0 then
				if global.PSCStatistics[force.name][itemName] == nil then
					global.PSCStatistics[force.name][itemName] = { type = "item", name = itemName, input = itemCount, output = 0, inputPrev = 0, outputPrev = 0 }
				else
					global.PSCStatistics[force.name][itemName].input = itemCount
				end
			end
		end
		
		-- Item Production Output
		for itemName, itemCount in pairs (force.item_production_statistics.output_counts) do
			if itemName ~= nil and itemCount ~= 0 then
				if global.PSCStatistics[force.name][itemName] == nil then
					global.PSCStatistics[force.name][itemName] = { type = "item", name = itemName, input = 0, output = itemCount, inputPrev = 0, outputPrev = 0 }
				else
					global.PSCStatistics[force.name][itemName].output = itemCount
				end
			end
		end
		
		-- Fluid Production Input
		for fluidName, fluidCount in pairs (force.fluid_production_statistics.input_counts) do
			if fluidName ~= nil and fluidCount ~= 0 then
				if global.PSCStatistics[force.name][fluidName] == nil then
					global.PSCStatistics[force.name][fluidName] = { type = "fluid", name = fluidName, input = fluidCount, output = 0, inputPrev = 0, outputPrev = 0 }
				else
					global.PSCStatistics[force.name][fluidName].input = fluidCount
				end
			end
		end
		
		-- Fluid Production Output
		for fluidName, fluidCount in pairs (force.fluid_production_statistics.output_counts) do
			if fluidName ~= nil and fluidCount ~= 0 then
				if global.PSCStatistics[force.name][fluidName] == nil then
					global.PSCStatistics[force.name][fluidName] = { type = "fluid", name = fluidName, input = 0, output = fluidCount, inputPrev = 0, outputPrev = 0 }
				else
					global.PSCStatistics[force.name][fluidName].output = fluidCount
				end
			end
		end
	end
end

function PSC_updatePreviousStats()
	for i, force in pairs(global.PSCStatistics) do
		for j, item in pairs(force) do
			item.inputPrev = item.input
			item.input = 0
			item.outputPrev = item.output
			item.output = 0
		end
	end
	
	global.PSCSignals = {}
end

function PSC_getInputSignals(force)
	if global.PSCSignals[force.name] ~= nil and global.PSCSignals[force.name]["input"] ~= nil then
		return global.PSCSignals[force.name]["input"]
	else
		if global.PSCSignals[force.name] == nil then
			global.PSCSignals[force.name] = {}
		end
		if global.PSCSignals[force.name]["input"] == nil then
			global.PSCSignals[force.name]["input"] = {}
		end
		
		local signals = {}
		local i = 1
		
		if global.PSCStatistics[force.name] ~= nil then
			for _, item in pairs(global.PSCStatistics[force.name]) do
				if item ~= nil and item.input > 0 then
					local s = { signal = { type = item.type, name = item.name }, count = item.input - item.inputPrev, index = i}
					if s.count > 2147483647 then
						s.count = 2147483647
					end
					table.insert( signals, s )
					i = i + 1
					
				end
			end
		end
		
		global.PSCSignals[force.name]["input"] = signals
		return signals
	end
end

function PSC_getOutputSignals(force)
	if global.PSCSignals[force.name] ~= nil and global.PSCSignals[force.name]["output"] ~= nil then
		return global.PSCSignals[force.name]["output"]
	else
		if global.PSCSignals[force.name] == nil then
			global.PSCSignals[force.name] = {}
		end
		if global.PSCSignals[force.name]["output"] == nil then
			global.PSCSignals[force.name]["output"] = {}
		end
		
		local signals = {}
		local i = 1

		if global.PSCStatistics[force.name] ~= nil then
			for _, item in pairs(global.PSCStatistics[force.name]) do
				if item ~= nil and item.output > 0 then
					local s = { signal = { type = item.type, name = item.name }, count = item.output - item.outputPrev, index = i}
					if s.count > 2147483647 then
						s.count = 2147483647
					end
					table.insert( signals, s )
					i = i + 1
				end
			end
		end
		
		global.PSCSignals[force.name]["output"] = signals
		return signals
	end
end

function PSC_getTotalSignals(force)
	if global.PSCSignals[force.name] ~= nil and global.PSCSignals[force.name]["total"] ~= nil then
		return global.PSCSignals[force.name]["total"]
	else
		if global.PSCSignals[force.name] == nil then
			global.PSCSignals[force.name] = {}
		end
		if global.PSCSignals[force.name]["total"] == nil then
			global.PSCSignals[force.name]["total"] = {}
		end
		
		local signals = {}
		local i = 1

		if global.PSCStatistics[force.name] ~= nil then
			for _, item in pairs(global.PSCStatistics[force.name]) do
				if item ~= nil then
					local s = { signal = { type = item.type, name = item.name }, count = item.input - item.inputPrev - (item.output - item.outputPrev), index = i}
					if s.count > 2147483647 then
						s.count = 2147483647
					end
					table.insert( signals, s )
					i = i + 1
				end
			end
		end
	
		global.PSCSignals[force.name]["total"] = signals
		return signals
	end
end

function PSC_getPercentageSignals(force)
	if global.PSCSignals[force.name] ~= nil and global.PSCSignals[force.name]["percentage"] ~= nil then
		return global.PSCSignals[force.name]["percentage"]
	else
		if global.PSCSignals[force.name] == nil then
			global.PSCSignals[force.name] = {}
		end
		if global.PSCSignals[force.name]["percentage"] == nil then
			global.PSCSignals[force.name]["percentage"] = {}
		end
		
		local signals = {}
		local i = 1

		if global.PSCStatistics[force.name] ~= nil then
			for _, item in pairs(global.PSCStatistics[force.name]) do
				if item ~= nil then
					local percentage = 0
					local input = (item.input - item.inputPrev)
					local output = (item.output - item.outputPrev)
					if input ~= 0 or output ~= 0 then
						if input == 0 then
							percentage = -100
						elseif output == 0 then
							percentage = 100
						else
							percentage = (input * 100 / output) - 100
						end
					
						local s = { signal = { type = item.type, name = item.name }, count = percentage, index = i}
						if s.count > 2147483647 then
							s.count = 2147483647
						end
						table.insert( signals, s )
						i = i + 1
					end
				end
			end
		end
		
		global.PSCSignals[force.name]["percentage"] = signals
		return signals
	end
end