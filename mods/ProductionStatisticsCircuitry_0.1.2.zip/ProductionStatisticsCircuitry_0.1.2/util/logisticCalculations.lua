function PSC_getRequestSignals(entity)
	if entity then
		local ind = 1
		local signals = {}
		local items = {}
		local logistic_network = entity.surface.find_logistic_network_by_position(entity.position, entity.force)
		
		if logistic_network ~= nil then
			for i, point in pairs(logistic_network.requester_points) do
				if point.filters ~= nil and point.mode == defines.logistic_mode.requester then
					for j, filter in pairs(point.filters) do
						-- We do this weird indexing because in lua you cannot find the length of an array that uses string indices
						if items[filter.name] == nil then
							signals[ind] = { signal = {type = "item", name = filter.name }, count = filter.count, index = ind }
							items[filter.name] = ind
							ind = ind + 1
						else
							signals[items[filter.name]].count = signals[items[filter.name]].count + filter.count
						end
					end
				end
			end
		end
		
		return signals
	end
	
	return {}
end

function PSC_getRequestsRemainingSignals(entity)
	if entity then
		local ind = 1
		local signals = {}
		local items = {}
		local logistic_network = entity.surface.find_logistic_network_by_position(entity.position, entity.force)
		
		if logistic_network ~= nil then
			for i, point in pairs(logistic_network.requester_points) do
				if point.filters ~= nil and point.mode == defines.logistic_mode.requester then
					for j, filter in pairs(point.filters) do
						local c = filter.count
						local inventory = point.owner.get_inventory(defines.inventory.chest)
						if inventory ~= nil then
							c = c - inventory.get_item_count(filter.name)
						end

						if items[filter.name] == nil then
							signals[ind] = { signal = {type = "item", name = filter.name }, count = c, index = ind }
							items[filter.name] = ind
							ind = ind + 1
						else
							signals[items[filter.name]].count = signals[items[filter.name]].count + c
						end
					end
				end
			end
		end
		
		return signals
	end
	
	return {}
end

function PSC_getAvailableItemsSignals(entity)
	if entity then
		local signals = {}
		local i = 1
		local logistic_network = entity.surface.find_logistic_network_by_position(entity.position, entity.force)
		
		if logistic_network ~= nil then
			local items = logistic_network.get_contents()
			
			for name, number in pairs (items) do
				local num = number
				if num > 2147483647 or num < 0 then
					num = 0
				end
			
				local s = { signal = { type = "item", name = name }, count = num, index = i }
				table.insert(signals, s)			
				
				i = i + 1			
			end
		end
		
		return signals
	end
	
	return {}
end

function PSC_getStatusSignals(entity)
	if entity then
		local logistic_network = entity.surface.find_logistic_network_by_position(entity.position, entity.force)
		
		if logistic_network ~= nil then
			-- L = logistic active
			-- C = construction active
			
			local limit = #logistic_network.cells * 350
			if limit > 2147483647 then
				limit = 2147483647
			end
			
			-- local s = 0
			-- for _, entity in pairs(logistic_network.storages) do
				-- if entity.get_inventory(defines.inventory.chest).is_empty() then
					-- s = s + 1
				-- end
			-- end
			
			return {
				{ signal = {type = "item", name = "logistic-robot"}, count = logistic_network.available_logistic_robots, index = 1 },
				{ signal = {type = "virtual", name = "signal-L"}, count = logistic_network.all_logistic_robots, index = 2 },
				{ signal = {type = "item", name = "construction-robot"}, count = logistic_network.available_construction_robots, index = 3 },
				{ signal = {type = "virtual", name = "signal-C"}, count = logistic_network.all_construction_robots, index = 4 },
				{ signal = {type = "virtual", name = "signal-R"}, count = limit, index = 5 },
				{ signal = {type = "virtual", name = "signal-T"}, count = limit - logistic_network.all_logistic_robots - logistic_network.all_construction_robots, index = 12 },
				{ signal = {type = "item", name = "roboport"}, count = #logistic_network.cells, index = 6 },
				{ signal = {type = "item", name = "logistic-chest-passive-provider"}, count = #logistic_network.passive_provider_points, index = 7 },
				{ signal = {type = "item", name = "logistic-chest-active-provider"}, count = #logistic_network.active_provider_points, index = 8 },
				{ signal = {type = "item", name = "logistic-chest-requester"}, count = #logistic_network.requester_points, index = 9 },
				{ signal = {type = "item", name = "logistic-chest-storage"}, count = #logistic_network.storage_points, index = 10 },
				-- { signal = {type = "virtual", name = "signal-S"}, count = s, index = 11 }
			}
		else
			return {
				-- { signal = {type = "item", name = "logistic-robot"}, count = 0, index = 1 },
				-- { signal = {type = "virtual", name = "signal-L"}, count = 0, index = 2 },
				-- { signal = {type = "item", name = "construction-robot"}, count = 0, index = 3 },
				-- { signal = {type = "virtual", name = "signal-C"}, count = 0, index = 4 },
				-- { signal = {type = "virtual", name = "signal-R"}, count = 0, index = 5 },
				-- { signal = {type = "item", name = "roboport"}, count = 0, index = 6 },
				-- { signal = {type = "item", name = "logistic-chest-passive-provider"}, count = 0, index = 7 },
				-- { signal = {type = "item", name = "logistic-chest-active-provider"}, count = 0, index = 8 },
				-- { signal = {type = "item", name = "logistic-chest-requester"}, count = 0, index = 9 },
				-- { signal = {type = "item", name = "logistic-chest-storage"}, count = 0, index = 10 },
				-- { signal = {type = "virtual", name = "signal-S"}, count = 0, index = 11 }
			}
		end
	end
	
	return {}
end