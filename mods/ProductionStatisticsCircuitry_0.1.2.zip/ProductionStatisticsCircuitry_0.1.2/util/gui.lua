require( "mod-gui" )

function PSC_ShowLGUI(player, index) 
	local flow0 = player.gui.center.add { type = "frame", name =  "LSCSelectOutputType", direction = "vertical", style = nil }
	local flow1 = flow0.add { type = "label", name = "LSCSelectOutputTypeLabel", caption = "Select Output Type", style = "description_title_label"}
	local flow2 = flow0.add { type = "drop-down", name = "LSCSelectOutputTypeDropDown", items = { "Requests", "Unfulfilled Requests", "Available Items", "Status" } }
	flow2.selected_index = index
	
	return flow0
end

function PSC_ShowPGUI(player, index) 
	local flow0 = player.gui.center.add { type = "frame", name =  "PSCSelectOutputType", direction = "vertical", style = nil }
	local flow1 = flow0.add { type = "label", name = "PSCSelectOutputTypeLabel", caption = "Select Output Type", style = "description_title_label"}
	local flow2 = flow0.add { type = "drop-down", name = "PSCSelectOutputTypeDropDown", items = { "Input Statistics", "Output Statistics", "Total Statistics", "Percentage Statistics" } }
	flow2.selected_index = index
	
	return flow0
end

script.on_event( defines.events.on_gui_opened, function( event )
	local player = game.players[event.player_index]
	
	if event.entity and event.entity.name == "logistic-statistics-combinator" then
		if player.gui.center.LSCSelectOutputType then player.gui.center.LSCSelectOutputType.destroy() end
		
		local entity = event.entity
		for _, e in pairs(global.LSCEntitiesRequests) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 1, entity = entity }
				player.opened = PSC_ShowLGUI(player, 1)
				return
			end
		end
		
		for _, e in pairs(global.LSCEntitiesRequestsRemaining) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 2, entity = entity }
				player.opened = PSC_ShowLGUI(player, 2)
				return
			end
		end
		
		for _, e in pairs(global.LSCEntitiesAvailableItems) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 3, entity = entity }
				player.opened = PSC_ShowLGUI(player, 3)
				return
			end
		end
		
		for _, e in pairs(global.LSCEntitiesStatus) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 4, entity = entity }
				player.opened = PSC_ShowLGUI(player, 4)
				return
			end
		end
		
		global.PSC_PlayerData[player.index] = { index = 0, entity = entity }
		player.opened = PSC_ShowLGUI(player, 0)
		return
	elseif event.entity and event.entity.name == "production-statistics-combinator" then
		if player.gui.center.PSCSelectOutputType then player.gui.center.PSCSelectOutputType.destroy() end
		
		local entity = event.entity
		for _, e in pairs(global.PSCEntitiesInput) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 1, entity = entity }
				player.opened = PSC_ShowPGUI(player, 1)
				return
			end
		end
		
		for _, e in pairs(global.PSCEntitiesOutput) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 2, entity = entity }
				player.opened = PSC_ShowPGUI(player, 2)
				return
			end
		end
		
		for _, e in pairs(global.PSCEntitiesTotal) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 3, entity = entity }
				player.opened = PSC_ShowPGUI(player, 3)
				return
			end
		end
		
		for _, e in pairs(global.PSCEntitiesPercentage) do
			if e == entity then
				global.PSC_PlayerData[player.index] = { index = 4, entity = entity }
				player.opened = PSC_ShowPGUI(player, 4)
				return
			end
		end
		
		global.PSC_PlayerData[player.index] = { index = 0, entity = entity }
		player.opened = PSC_ShowPGUI(player, 0)
		return
	end
end )

script.on_event( defines.events.on_gui_selection_state_changed, function( event )
	local element = event.element
	local player = game.players[event.player_index]
	local name = element.name
	
	if name == "LSCSelectOutputTypeDropDown" then
		local data = global.PSC_PlayerData[player.index]
		local entity = data.entity
		local index = data.index
		local newIndex = element.selected_index
		
		-- Find and remove current entity from list
		if index == 1 then
			for i, e in ipairs(global.LSCEntitiesRequests) do
				if e == entity then
					table.remove(global.LSCEntitiesRequests, i)
					break
				end
			end
		elseif index == 2 then
			for i, e in ipairs(global.LSCEntitiesRequestsRemaining) do
				if e == entity then
					table.remove(global.LSCEntitiesRequestsRemaining, i)
					break
				end
			end
		elseif index == 3 then 
			for i, e in ipairs(global.LSCEntitiesAvailableItems) do
				if e == entity then
					table.remove(global.LSCEntitiesAvailableItems, i)
					break
				end
			end
		elseif index == 4 then
			for i, e in ipairs(global.LSCEntitiesStatus) do
				if e == entity then
					table.remove(global.LSCEntitiesStatus, i)
					found = true
					break
				end
			end
		end
		
		-- Add to list
		if newIndex == 1 then
			table.insert( global.LSCEntitiesRequests, data.entity)
			global.PSC_PlayerData[player.index].index = 1
		elseif newIndex == 2 then
			table.insert( global.LSCEntitiesRequestsRemaining, data.entity)
			global.PSC_PlayerData[player.index].index = 2
		elseif newIndex == 3 then
			table.insert( global.LSCEntitiesAvailableItems, data.entity)
			global.PSC_PlayerData[player.index].index = 3
		elseif newIndex == 4 then
			table.insert( global.LSCEntitiesStatus, data.entity)
			global.PSC_PlayerData[player.index].index = 4
		end
	elseif name == "PSCSelectOutputTypeDropDown" then
		local data = global.PSC_PlayerData[player.index]
		local entity = data.entity
		local index = data.index
		local newIndex = element.selected_index
		
		-- Find and remove current entity from list
		if index == 1 then
			for i, e in ipairs(global.PSCEntitiesInput) do
				if e == entity then
					table.remove(global.PSCEntitiesInput, i)
					break
				end
			end
		elseif index == 2 then
			for i, e in ipairs(global.PSCEntitiesOutput) do
				if e == entity then
					table.remove(global.PSCEntitiesOutput, i)
					break
				end
			end
		elseif index == 3 then 
			for i, e in ipairs(global.PSCEntitiesTotal) do
				if e == entity then
					table.remove(global.PSCEntitiesTotal, i)
					break
				end
			end
		elseif index == 4 then
			for i, e in ipairs(global.PSCEntitiesPercentage) do
				if e == entity then
					table.remove(global.PSCEntitiesPercentage, i)
					found = true
					break
				end
			end
		end
		
		-- Add to list
		if newIndex == 1 then
			table.insert( global.PSCEntitiesInput, data.entity)
			global.PSC_PlayerData[player.index].index = 1
		elseif newIndex == 2 then
			table.insert( global.PSCEntitiesOutput, data.entity)
			global.PSC_PlayerData[player.index].index = 2
		elseif newIndex == 3 then
			table.insert( global.PSCEntitiesTotal, data.entity)
			global.PSC_PlayerData[player.index].index = 3
		elseif newIndex == 4 then
			table.insert( global.PSCEntitiesPercentage, data.entity)
			global.PSC_PlayerData[player.index].index = 4
		end
	end
	
	return
end )

script.on_event( defines.events.on_gui_closed, function( event )
	if event.element and event.element.name == "LSCSelectOutputType" then
		event.element.destroy()
		global.PSC_PlayerData[game.players[event.player_index].index] = nil
	elseif event.element and event.element.name == "PSCSelectOutputType" then
		event.element.destroy()
		global.PSC_PlayerData[game.players[event.player_index].index] = nil
	end
end )