data:extend ({ 
	{ 
		type = "int-setting", 
		name = "Production-Statistics-Updates", 
		setting_type = "runtime-global", 
		order = "01", 
		default_value = 300, 
		minimum_value = 5, 
		maximum_value = 216000
	} 
})