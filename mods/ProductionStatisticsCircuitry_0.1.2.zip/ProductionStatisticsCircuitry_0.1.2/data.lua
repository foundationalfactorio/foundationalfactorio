--data.lua

require("prototypes.item")
require("prototypes.entity")
require("prototypes.tech")
require("prototypes.recipe")