--recipes.lua

data:extend({
	{
		enabled = false,
		energy_required = 0.5,
		ingredients = {
			{ "copper-cable", 5 },
			{ "electronic-circuit", 5 }
		},
		name = "production-statistics-combinator",
		result = "production-statistics-combinator",
		category = "crafting",
		type = "recipe"
	}
})

data:extend({
	{
		enabled = false,
		energy_required = 0.5,
		ingredients = {
			{ "copper-cable", 5 },
			{ "electronic-circuit", 5 }
		},
		name = "logistic-statistics-combinator",
		result = "logistic-statistics-combinator",
		category = "crafting",
		type = "recipe"
	}
})