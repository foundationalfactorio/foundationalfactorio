--item.lua

data:extend({
	{
      flags = {
        "goes-to-quickbar"
      },
      icon = "__ProductionStatisticsCircuitry__/graphics/icons/production-statistics-combinator.png",
      icon_size = 32,
      name = "production-statistics-combinator",
      order = "c[constant-combinator]-d[production-statistics-combinator]",
      place_result = "production-statistics-combinator",
      stack_size = 50,
      subgroup = "circuit-network",
      type = "item"
    }
})

data:extend({
	{
      flags = {
        "goes-to-quickbar"
      },
      icon = "__ProductionStatisticsCircuitry__/graphics/icons/logistic-statistics-combinator.png",
      icon_size = 32,
      name = "logistic-statistics-combinator",
      order = "c[production-statistics-combinator]-d[logistic-statistics-combinator]",
      place_result = "logistic-statistics-combinator",
      stack_size = 50,
      subgroup = "circuit-network",
      type = "item"
    }
})