--entity.lua

data:extend({
	{
      activity_led_light = {
        color = {
          b = 1,
          g = 1,
          r = 1
        },
        intensity = 0.8,
        size = 1
      },
      activity_led_light_offsets = {
        {
          0.296875,
          -0.40625
        },
        {
          0.25,
          -0.03125
        },
        {
          -0.296875,
          -0.078125
        },
        {
          -0.21875,
          -0.46875
        }
      },
      activity_led_sprites = {
        east = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-E.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-E.png",
            frame_count = 1,
            height = 14,
            scale = 0.5,
            shift = {
              0.234375,
              -0.015625
            },
            width = 14
          },
          shift = {
            0.25,
            0
          },
          width = 8
        },
        north = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-N.png",
          frame_count = 1,
          height = 6,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-N.png",
            frame_count = 1,
            height = 12,
            scale = 0.5,
            shift = {
              0.28125,
              -0.359375
            },
            width = 14
          },
          shift = {
            0.28125,
            -0.375
          },
          width = 8
        },
        south = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-S.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-S.png",
            frame_count = 1,
            height = 16,
            scale = 0.5,
            shift = {
              -0.28125,
              0.078125
            },
            width = 14
          },
          shift = {
            -0.28125,
            0.0625
          },
          width = 8
        },
        west = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-W.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-W.png",
            frame_count = 1,
            height = 16,
            scale = 0.5,
            shift = {
              -0.21875,
              -0.46875
            },
            width = 14
          },
          shift = {
            -0.21875,
            -0.46875
          },
          width = 8
        }
      },
      circuit_wire_connection_points = {
        {
          shadow = {
            green = {
              0.71875,
              -0.1875
            },
            red = {
              0.21875,
              -0.1875
            }
          },
          wire = {
            green = {
              0.21875,
              -0.546875
            },
            red = {
              -0.265625,
              -0.546875
            }
          }
        },
        {
          shadow = {
            green = {
              1,
              0.25
            },
            red = {
              1,
              -0.15625
            }
          },
          wire = {
            green = {
              0.5,
              -0.109375
            },
            red = {
              0.5,
              -0.515625
            }
          }
        },
        {
          shadow = {
            green = {
              0.28125,
              0.625
            },
            red = {
              0.78125,
              0.625
            }
          },
          wire = {
            green = {
              -0.203125,
              0.234375
            },
            red = {
              0.28125,
              0.234375
            }
          }
        },
        {
          shadow = {
            green = {
              0.03125,
              -0.0625
            },
            red = {
              0.03125,
              0.34375
            }
          },
          wire = {
            green = {
              -0.46875,
              -0.421875
            },
            red = {
              -0.46875,
              -0.015625
            }
          }
        }
      },
      circuit_wire_max_distance = 9,
      collision_box = {
        {
          -0.35,
          -0.35
        },
        {
          0.35,
          0.35
        }
      },
      corpse = "small-remnants",
      flags = {
        "placeable-neutral",
        "player-creation"
      },
      icon = "__ProductionStatisticsCircuitry__/graphics/icons/production-statistics-combinator.png",
      icon_size = 32,
      item_slot_count = 1024,
      max_health = 120,
      minable = {
        hardness = 0.2,
        mining_time = 0.5,
        result = "production-statistics-combinator"
      },
      name = "production-statistics-combinator",
      selection_box = {
        {
          -0.5,
          -0.5
        },
        {
          0.5,
          0.5
        }
      },
      sprites = {
        east = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = {
                  0,
                  0.15625
                },
                width = 114,
                x = 114
              },
              priority = "high",
              scale = 1,
              shift = {
                0,
                0.15625
              },
              width = 58,
              x = 58
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = {
                  0.265625,
                  0.171875
                },
                width = 98,
                x = 98
              },
              priority = "high",
              scale = 1,
              shift = {
                0.28125,
                0.1875
              },
              width = 50,
              x = 50
            }
          }
        },
        north = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 0
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 0
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 0
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 0
            }
          }
        },
        south = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 228
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 116
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 196
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 100
            }
          }
        },
        west = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 342
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 174
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/constant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/hr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 294
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 150
            }
          }
        }
      },
      type = "constant-combinator",
      vehicle_impact_sound = {
        filename = "__base__/sound/car-metal-impact.ogg",
        volume = 0.65
      }
    }
})

data:extend({
	{
      activity_led_light = {
        color = {
          b = 1,
          g = 1,
          r = 1
        },
        intensity = 0.8,
        size = 1
      },
      activity_led_light_offsets = {
        {
          0.296875,
          -0.40625
        },
        {
          0.25,
          -0.03125
        },
        {
          -0.296875,
          -0.078125
        },
        {
          -0.21875,
          -0.46875
        }
      },
      activity_led_sprites = {
        east = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-E.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-E.png",
            frame_count = 1,
            height = 14,
            scale = 0.5,
            shift = {
              0.234375,
              -0.015625
            },
            width = 14
          },
          shift = {
            0.25,
            0
          },
          width = 8
        },
        north = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-N.png",
          frame_count = 1,
          height = 6,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-N.png",
            frame_count = 1,
            height = 12,
            scale = 0.5,
            shift = {
              0.28125,
              -0.359375
            },
            width = 14
          },
          shift = {
            0.28125,
            -0.375
          },
          width = 8
        },
        south = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-S.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-S.png",
            frame_count = 1,
            height = 16,
            scale = 0.5,
            shift = {
              -0.28125,
              0.078125
            },
            width = 14
          },
          shift = {
            -0.28125,
            0.0625
          },
          width = 8
        },
        west = {
          filename = "__base__/graphics/entity/combinator/activity-leds/constant-combinator-LED-W.png",
          frame_count = 1,
          height = 8,
          hr_version = {
            filename = "__base__/graphics/entity/combinator/activity-leds/hr-constant-combinator-LED-W.png",
            frame_count = 1,
            height = 16,
            scale = 0.5,
            shift = {
              -0.21875,
              -0.46875
            },
            width = 14
          },
          shift = {
            -0.21875,
            -0.46875
          },
          width = 8
        }
      },
      circuit_wire_connection_points = {
        {
          shadow = {
            green = {
              0.71875,
              -0.1875
            },
            red = {
              0.21875,
              -0.1875
            }
          },
          wire = {
            green = {
              0.21875,
              -0.546875
            },
            red = {
              -0.265625,
              -0.546875
            }
          }
        },
        {
          shadow = {
            green = {
              1,
              0.25
            },
            red = {
              1,
              -0.15625
            }
          },
          wire = {
            green = {
              0.5,
              -0.109375
            },
            red = {
              0.5,
              -0.515625
            }
          }
        },
        {
          shadow = {
            green = {
              0.28125,
              0.625
            },
            red = {
              0.78125,
              0.625
            }
          },
          wire = {
            green = {
              -0.203125,
              0.234375
            },
            red = {
              0.28125,
              0.234375
            }
          }
        },
        {
          shadow = {
            green = {
              0.03125,
              -0.0625
            },
            red = {
              0.03125,
              0.34375
            }
          },
          wire = {
            green = {
              -0.46875,
              -0.421875
            },
            red = {
              -0.46875,
              -0.015625
            }
          }
        }
      },
      circuit_wire_max_distance = 9,
      collision_box = {
        {
          -0.35,
          -0.35
        },
        {
          0.35,
          0.35
        }
      },
      corpse = "small-remnants",
      flags = {
        "placeable-neutral",
        "player-creation"
      },
      icon = "__ProductionStatisticsCircuitry__/graphics/icons/logistic-statistics-combinator.png",
      icon_size = 32,
      item_slot_count = 1024,
      max_health = 120,
      minable = {
        hardness = 0.2,
        mining_time = 0.5,
        result = "logistic-statistics-combinator"
      },
      name = "logistic-statistics-combinator",
      selection_box = {
        {
          -0.5,
          -0.5
        },
        {
          0.5,
          0.5
        }
      },
      sprites = {
        east = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = {
                  0,
                  0.15625
                },
                width = 114,
                x = 114
              },
              priority = "high",
              scale = 1,
              shift = {
                0,
                0.15625
              },
              width = 58,
              x = 58
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = {
                  0.265625,
                  0.171875
                },
                width = 98,
                x = 98
              },
              priority = "high",
              scale = 1,
              shift = {
                0.28125,
                0.1875
              },
              width = 50,
              x = 50
            }
          }
        },
        north = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 0
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 0
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 0
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 0
            }
          }
        },
        south = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 228
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 116
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 196
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 100
            }
          }
        },
        west = {
          layers = {
            {
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator.png",
              frame_count = 1,
              height = 52,
              hr_version = {
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator.png",
                frame_count = 1,
                height = 102,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 114,
                x = 342
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 58,
              x = 174
            },
            {
              draw_as_shadow = true,
              filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logisticconstant-combinator-shadow.png",
              frame_count = 1,
              height = 34,
              hr_version = {
                draw_as_shadow = true,
                filename = "__ProductionStatisticsCircuitry__/graphics/entity/combinator/logistichr-constant-combinator-shadow.png",
                frame_count = 1,
                height = 66,
                priority = "high",
                scale = 0.5,
                shift = nil,
                width = 98,
                x = 294
              },
              priority = "high",
              scale = 1,
              shift = nil,
              width = 50,
              x = 150
            }
          }
        }
      },
      type = "constant-combinator",
      vehicle_impact_sound = {
        filename = "__base__/sound/car-metal-impact.ogg",
        volume = 0.65
      }
    }
})