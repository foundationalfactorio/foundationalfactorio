--tech.lua

data:extend({
	{
		effects = {
			{
				recipe = "production-statistics-combinator",
				type = "unlock-recipe"
			},
			{
				recipe = "logistic-statistics-combinator",
				type = "unlock-recipe"
			}
		},
		icon = "__ProductionStatisticsCircuitry__/graphics/technology/production-statistics-combinator.png",
		icon_size = 128,
		name = "production-statistics-combinator",
		order = "a[circuit-network]-b[production-statistics-combinator]",
		prerequisites = {
			"circuit-network"
		},
		type = "technology",
		unit = {
			count = 25,
			ingredients = {
				{ "science-pack-1", 1 },
				{ "science-pack-2", 1 }
			},
			time = 30
		}
	}
})