require("prototypes.smelting-override-global")

-- EXECUTE OVERRIDES
angelsmods.functions.OV.execute()
	