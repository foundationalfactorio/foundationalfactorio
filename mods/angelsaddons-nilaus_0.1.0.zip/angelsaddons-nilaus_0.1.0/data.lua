if not angelsmods then angelsmods = {} end
if not angelsmods.addons then angelsmods.addons = {} end
if not angelsmods.addons.decorations then angelsmods.addons.decorations = {} end

require("prototypes.buildings.deco-nilaus")
require("prototypes.recipes.decorations")

