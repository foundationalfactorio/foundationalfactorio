data:extend(
{
	{
    type = "recipe",
    name = "deco-nilaus-1",
    energy_required = 2,
	enabled = "true",
    ingredients ={
	{"iron-plate", 5},
	{"steel-plate", 5},
	{"stone-brick", 5},
	},
    result= "deco-nilaus-1",
    },
	{
    type = "recipe",
    name = "deco-nilaus-2",
    energy_required = 2,
	enabled = "true",
    ingredients ={
	{"iron-plate", 5},
	{"steel-plate", 5},
	{"stone-brick", 5},
	},
    result= "deco-nilaus-2",
    },
  }
  )