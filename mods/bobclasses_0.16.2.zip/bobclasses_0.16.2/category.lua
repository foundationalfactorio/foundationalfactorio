data:extend
{
  {
    type = "item-subgroup",
    name = "bodies",
    group = "logistics",
    order = "aa",
  },
  {
    type = "item-subgroup",
    name = "body-parts",
    group = "intermediate-products",
    order = "i"
  },
}

