data:extend({
	{
     type = "sprite",
     name = "DeleteEmptyChunks_button",
     filename = "__DeleteEmptyChunks__/graphics/DeleteEmptyChunks_button.png",
     priority = "extra-high-no-scale",
     width = 32,
     height = 32
	},
})
